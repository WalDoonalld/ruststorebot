const cheerio = require('cheerio');

async function fetchHtml(url) {
  const res = await fetch(url, {
    headers: {
      'User-Agent': 'Mozilla/5.0',
      'Accept-Language': 'en-US,en;q=0.9'
    }
  });
  return await res.text();
}

function normalizeUrl(href) {
  if (!href) return null;
  if (href.startsWith('http')) return href;
  return new URL(href, 'https://store.steampowered.com').toString();
}

function textTrim(s) {
  return (s || '').replace(/\s+/g, ' ').trim();
}

async function getCurrentStore() {
  const url = 'https://store.steampowered.com/itemstore/252490/?l=english&filter=All&cc=US';
  const html = await fetchHtml(url);
  const $ = cheerio.load(html);

  const items = [];
  $('a[href*="/itemstore/252490/detail/"]').each((_, el) => {
    const a = $(el);
    const container = a.closest('div');
    let name = textTrim(a.text()) || textTrim(a.attr('title'));
    let price = textTrim(container.find('.price, .discount_final_price, .store_item_price, .game_purchase_price').first().text());
    let image = a.find('img').attr('src') || a.find('img').attr('data-src');
    const link = normalizeUrl(a.attr('href'));

    if (!name && link) {
      const m = link.match(/detail\/(\d+)/);
      if (m) name = `Item ${m[1]}`;
    }

    if (link && !items.find(i => i.url === link)) {
      items.push({ name, price, image, url: link });
    }
  });

  return items;
}

module.exports = { getCurrentStore };